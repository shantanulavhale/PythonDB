import pymysql

try:
    con=pymysql.connect(host='bbke82kiwibb2ybfstzi-mysql.services.clever-cloud.com',user='usw2c4kq2fttydxr',password='PmCIjfuj9uq20Q6aif4Y',database='bbke82kiwibb2ybfstzi')
    curs=con.cursor()
    
    bookcode=int(input("Enter Bookcode : "))

    curs.execute("select * from books where bookcode=%d" %bookcode)
    data=curs.fetchone()

    print("Book name : ",data[1])
    print("Author    : ",data[3])
    print("category  : ",data[2])
    print("price     : ",data[6])

except Exception as e:
    print("Book not found ! ",e)

con.close()

