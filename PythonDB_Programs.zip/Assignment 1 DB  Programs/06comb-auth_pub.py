import pymysql

con=pymysql.connect(host='bbke82kiwibb2ybfstzi-mysql.services.clever-cloud.com',user='usw2c4kq2fttydxr',password='PmCIjfuj9uq20Q6aif4Y',database='bbke82kiwibb2ybfstzi')
curs=con.cursor()

try:
    auth=input("Enter Author : ")
    pub=input("Enter Publication : ")

    curs.execute("select Author,Publication from books where Author='%s' and Publication='%s' "%(auth,pub))
    data=curs.fetchall()
    if data:
        curs.execute("select bookname from books where Author='%s' and Publication='%s' "%(auth,pub))
        dt=curs.fetchall()
        print("_____List of books_____")
        for rec in dt:
            print(rec[0])
        

except Exception as e:
    print("book not found ! ",e)