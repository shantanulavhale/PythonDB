import pymysql

con=pymysql.connect(host='bbke82kiwibb2ybfstzi-mysql.services.clever-cloud.com',user='usw2c4kq2fttydxr',password='PmCIjfuj9uq20Q6aif4Y',database='bbke82kiwibb2ybfstzi')
curs=con.cursor()

curs.execute("select bookname from books")
data=curs.fetchall()

print("_____List of all books_____ ")
print()

for book in data:
    print(book[0])

con.close()

