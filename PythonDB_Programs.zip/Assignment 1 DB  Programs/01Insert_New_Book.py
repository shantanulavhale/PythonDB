import pymysql

print('_____New Book Detailes_____')

try:
   bookcode=int(input("Enter Bookcode : "))
   booknm=input("Enter bookname : ")
   cate=input("Enter category : ")
   auth=input("Enter author : ")
   pub=input("Enter publication : ")
   edi=int(input("Enter edition : "))
   price=int(input("Enter Price : "))

   con=pymysql.connect(host='bbke82kiwibb2ybfstzi-mysql.services.clever-cloud.com',user='usw2c4kq2fttydxr',password='PmCIjfuj9uq20Q6aif4Y',database='bbke82kiwibb2ybfstzi')

   curs=con.cursor()

   curs.execute("insert into books values(%d,'%s','%s','%s','%s',%d,%d)" %(bookcode,booknm,cate,auth,pub,edi,price))
   con.commit()

   print("Book added succesfully")


except Exception as e:
   print("New book added failed",e)

con.close()

