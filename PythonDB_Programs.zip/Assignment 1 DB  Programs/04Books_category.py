import pymysql

con=pymysql.connect(host='bbke82kiwibb2ybfstzi-mysql.services.clever-cloud.com',user='usw2c4kq2fttydxr',password='PmCIjfuj9uq20Q6aif4Y',database='bbke82kiwibb2ybfstzi')
curs=con.cursor()

try:
    cat=input("Enter category : ")
    curs.execute("select category from books where category=%s",cat)
    db=curs.fetchall()
    if db:
        curs.execute("select bookname from books where category=%s",cat)
        data=curs.fetchall()
        print("List of all books of category:",cat)
        for rec in data:
            print(rec[0])
    else:
        print("books not found !")

except Exception as e:
    print(e)
con.close()

