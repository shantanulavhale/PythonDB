import pymysql

con=pymysql.connect(host='bbke82kiwibb2ybfstzi-mysql.services.clever-cloud.com',user='usw2c4kq2fttydxr',password='PmCIjfuj9uq20Q6aif4Y',database='bbke82kiwibb2ybfstzi')
curs=con.cursor()

try:
    Bcode=int(input("Enter bookcode : "))
    curs.execute("select bookname,bookcode from books where bookCode=%d"%Bcode)
    dt=curs.fetchone()
    print("bookname :",dt[0])

    if dt:
        rev=input("Enter review : ")
        curs.execute("update books set Review='%s' where bookcode=%d"%(rev,Bcode))
        con.commit()
        print("review updated successfully..")
    else:
        print("Book not found !")


except Exception as e:
    print("Error in updating..",e)

